namespace test1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnChangeAll_Click(object sender, EventArgs e)
        {
            // 폼에 있는 모든 컨트롤을 순회하는 foreach 반복문
            foreach (Control ctrl in this.Controls)
            {
                // 현재 컨트롤이 Label 타입인지 확인하는 조건문
                if (ctrl is Label)
                {
                    // 컨트롤을 Label 타입으로 캐스팅하여 변수에 할당
                    Label lbl = (Label)ctrl;

                    // Label의 속성 변경
                    lbl.Text = "변경되었습니다!";
                    lbl.BackColor = System.Drawing.Color.SkyBlue;
                    lbl.ForeColor = System.Drawing.Color.DarkBlue;
                }
            }
        }
        }
    }
