namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            // 1. TextBox의 텍스트를 변수에 저장합니다.
            string strNum1 = txtNum1.Text;
            string strNum2 = txtNum2.Text;

            // 2. 문자열을 숫자로 변환합니다. (int 타입으로)
            // int.Parse() 메서드는 문자열을 정수로 변환합니다.
            int num1 = int.Parse(strNum1);
            int num2 = int.Parse(strNum2);

            // 3. 변수에 저장된 두 숫자를 더합니다.
            int result = num1 + num2;

            // 4. 결과를 문자열로 변환하여 Label에 표시합니다.
            // ToString() 메서드는 숫자를 문자열로 변환합니다.
            lblResult.Text = result.ToString();



        }
    }
}
