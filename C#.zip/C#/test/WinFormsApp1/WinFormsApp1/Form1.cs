using System.IO.Ports;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        SerialPort port = new SerialPort("COM10", 9600);


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            port.Open();
            port.Write("1");
            port.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            port.Open();
            port.Write("0");
            port.Close();
        }
    }
}
