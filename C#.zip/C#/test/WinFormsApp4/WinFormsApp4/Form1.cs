namespace WinFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {



            // 미리 정해놓은 올바른 아이디와 비밀번호
            string correctId = "admin";
            string correctPw = "1234";

            // 사용자가 입력한 아이디와 비밀번호를 변수에 저장
            string userId = txtUserId.Text;
            string userPw = txtPassword.Text;

            // 1. 입력된 값이 비어 있는지 확인하는 조건문
            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(userPw))
            {
                lblMessage.Text = "아이디와 비밀번호를 모두 입력해주세요.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
            // 2. 입력된 값이 올바른지 확인하는 조건문
            else if (userId == correctId && userPw == correctPw)
            {
                lblMessage.Text = "로그인 성공!";
                lblMessage.ForeColor = System.Drawing.Color.Green;
            }
            // 3. 모든 조건이 거짓일 때
            else
            {
                lblMessage.Text = "로그인 실패. 아이디 또는 비밀번호를 확인해주세요.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }



        }
    }
}
