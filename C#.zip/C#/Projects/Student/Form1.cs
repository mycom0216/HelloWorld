using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Student
{
    public partial class Form1 : Form
    {
        // Student 객체를 저장할 리스트 선언
        private List<Student> students = new List<Student>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 폼이 로드될 때 실행할 초기화 코드가 필요하면 이곳에 추가하세요.
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 사용자 입력값 가져오기
            string name = txtName.Text;
            int studentId = int.Parse(txtStudentId.Text);

            // Student 클래스의 새로운 객체(인스턴스) 생성
            Student newStudent = new Student(name, studentId);

            // 리스트에 객체 추가
            students.Add(newStudent);

            // ListBox에 객체 추가 (ToString() 메서드가 자동 호출됨)
            lstStudents.Items.Add(newStudent);

            // 입력란 초기화
            txtName.Clear();
            txtStudentId.Clear();
        }

        private void lstStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstStudents.SelectedItem is Student selectedStudent)
            {
                lblDetails.Text =
                    $"이름: {selectedStudent.Name}\n학번: {selectedStudent.StudentId}";
            }
        }

        private void lblDetails_Click(object sender, EventArgs e)
        {
            // 클릭 시 현재 선택된 학생의 상세 정보를 보여줍니다. 선택된 학생이 없으면 아무 동작도 하지 않습니다.
            if (lstStudents.SelectedItem is Student selectedStudent)
            {
                lblDetails.Text =
                    $"이름: {selectedStudent.Name}\n학번: {selectedStudent.StudentId}";
            }
        }
    }
}
