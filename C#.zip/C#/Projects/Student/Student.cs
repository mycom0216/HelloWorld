﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Student
{
    public class Student
    {
        // 속성 (Property)
        public string Name { get; set; }
        public int StudentId { get; set; }

        // 생성자 (Constructor): 객체 생성 시 초기화
        public Student(string name, int studentId)
        {
            this.Name = name;
            this.StudentId = studentId;
        }

        // ListBox에 표시될 문자열을 반환하는 메서드
        public override string ToString()
        {
            return $"이름: {Name} (학번: {StudentId})";

        }
    }
}
