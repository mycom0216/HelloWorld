namespace test3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;

            if (clickedButton.Text == "빨강")
            {
                BackColor = Color.Red;
            }
            else if (clickedButton.Text == "파랑")
            {
                BackColor = Color.Blue;
            }
            else if (clickedButton.Text == "초록")
            {
                BackColor = Color.Green;
            }
        }
    }
}
