﻿namespace test3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRed = new Button();
            btnBlue = new Button();
            btnGreen = new Button();
            SuspendLayout();
            // 
            // btnRed
            // 
            btnRed.Location = new Point(53, 37);
            btnRed.Name = "btnRed";
            btnRed.Size = new Size(75, 23);
            btnRed.TabIndex = 0;
            btnRed.Text = "빨강";
            btnRed.UseVisualStyleBackColor = true;
            btnRed.Click += btnColor_Click;
            // 
            // btnBlue
            // 
            btnBlue.Location = new Point(53, 81);
            btnBlue.Name = "btnBlue";
            btnBlue.Size = new Size(75, 23);
            btnBlue.TabIndex = 1;
            btnBlue.Text = "파랑";
            btnBlue.UseVisualStyleBackColor = true;
            btnBlue.Click += btnColor_Click;
            // 
            // btnGreen
            // 
            btnGreen.Location = new Point(53, 126);
            btnGreen.Name = "btnGreen";
            btnGreen.Size = new Size(75, 23);
            btnGreen.TabIndex = 2;
            btnGreen.Text = "초록";
            btnGreen.UseVisualStyleBackColor = true;
            btnGreen.Click += btnColor_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGreen);
            Controls.Add(btnBlue);
            Controls.Add(btnRed);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnRed;
        private Button btnBlue;
        private Button btnGreen;
    }
}
