﻿using System;
using System.Collections.Generic;
using System.Text;

namespace todolist
{
    public class TaskItem
    {
        public string Description { get; set; }
        public bool IsCompleted { get; set; }

        public TaskItem(string description)
        
        {
        
            this.Description = description;
            this.IsCompleted = false;
        }

        public override string ToString()
        {
            return $"[{(IsCompleted ? "✔" : " ")}] {Description}";
        }
    }
}
