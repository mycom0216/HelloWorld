using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Linq;
namespace todolist
{
    public partial class Form1 : Form
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private readonly string filePath = "tasks.txt";

        public Form1()
        {
            InitializeComponent();
            LoadTasksFromFile(); // 앱 시작 시 파일에서 목록 불러오기
        }

        // 할 일 추가
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string description = txtNewTask.Text.Trim();
            if (description.Length > 0)
            {
                tasks.Add(new TaskItem(description));
                RefreshTaskList();
                txtNewTask.Clear();
                txtNewTask.Focus();
                MessageBox.Show("할 일이 추가되었습니다.");
            }
        }

        private void txtNewTask_TextChanged(object sender, EventArgs e)
        {
            btnAdd.Enabled = !string.IsNullOrWhiteSpace(txtNewTask.Text);
        }

        // 할 일 삭제
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedIndex != -1)
            {
                tasks.RemoveAt(lstTasks.SelectedIndex);
                RefreshTaskList();
            }
        }

        // 완료 상태 변경
        private void chkCompleted_CheckedChanged(object sender, EventArgs e)
        {
            if (lstTasks.SelectedIndex != -1)
            {
                if (lstTasks.SelectedItem is TaskItem selectedTask)
                {
                    selectedTask.IsCompleted = chkCompleted.Checked;
                    RefreshTaskList(); // 상태 변경을 반영하기 위해 목록 갱신
                }
            }
        }

        // 목록 갱신 메서드
        private void RefreshTaskList()
        {
            lstTasks.Items.Clear();
            foreach (var task in tasks)
            {
                lstTasks.Items.Add(task);
            }
        }

        // 할 일 목록 저장 (파일 입출력)
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (var task in tasks)
                    {
                        writer.WriteLine($"{task.IsCompleted},{task.Description}");
                    }
                }
                MessageBox.Show("할 일 목록이 저장되었습니다.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"저장 오류: {ex.Message}");
            }
        }

        // 할 일 목록 불러오기 (파일 입출력)
        private void LoadTasksFromFile()
        {
            if (File.Exists(filePath))
            {
                try
                {
                    tasks.Clear();
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string? line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split(',');
                            if (parts.Length >= 2)
                            {
                                bool isCompleted = bool.TryParse(parts[0], out bool parsedCompleted) && parsedCompleted;
                                string description = parts[1];
                                TaskItem task = new TaskItem(description);
                                task.IsCompleted = isCompleted;
                                tasks.Add(task);
                            }
                        }
                    }
                    RefreshTaskList();
                    MessageBox.Show("할 일 목록을 불러왔습니다.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"불러오기 오류: {ex.Message}");
                }
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadTasksFromFile();
        }

        // ListBox 선택 항목 변경 시 CheckBox 상태 동기화
        private void lstTasks_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstTasks.SelectedIndex != -1)
            {
                if (lstTasks.SelectedItem is TaskItem selectedTask)
                {
                    chkCompleted.Checked = selectedTask.IsCompleted;
                }
            }
        }

    }
}
