﻿using System.Windows.Forms;

namespace todolist
{
    partial class Form1 : Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNewTask = new TextBox();
            btnAdd = new Button();
            lstTasks = new ListBox();
            btnRemove = new Button();
            btnSave = new Button();
            btnLoad = new Button();
            chkCompleted = new CheckBox();
            grpAdd = new GroupBox();
            grpList = new GroupBox();
            SuspendLayout();
            // 
            // txtNewTask
            // 
            txtNewTask.Location = new Point(15, 30);
            txtNewTask.Name = "txtNewTask";
            txtNewTask.Size = new Size(132, 23);
            txtNewTask.TabIndex = 0;
            txtNewTask.TextChanged += txtNewTask_TextChanged;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(170, 30);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "추가";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // lstTasks
            // 
            lstTasks.FormattingEnabled = true;
            lstTasks.Location = new Point(15, 30);
            lstTasks.Name = "lstTasks";
            lstTasks.Size = new Size(120, 94);
            lstTasks.TabIndex = 2;
            lstTasks.SelectedIndexChanged += lstTasks_SelectedIndexChanged;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(140, 65);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(95, 44);
            btnRemove.TabIndex = 3;
            btnRemove.Text = "삭제";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(74, 267);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 4;
            btnSave.Text = "저장";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(194, 267);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(75, 23);
            btnLoad.TabIndex = 5;
            btnLoad.Text = "불러오기";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // chkCompleted
            // 
            chkCompleted.AutoSize = true;
            chkCompleted.Location = new Point(150, 30);
            chkCompleted.Name = "chkCompleted";
            chkCompleted.Size = new Size(50, 19);
            chkCompleted.TabIndex = 6;
            chkCompleted.Text = "완료";
            chkCompleted.UseVisualStyleBackColor = true;
            chkCompleted.CheckedChanged += chkCompleted_CheckedChanged;
            // 
            // grpAdd
            // 
            grpAdd.Location = new Point(20, 20);
            grpAdd.Name = "grpAdd";
            grpAdd.Size = new Size(250, 80);
            grpAdd.TabIndex = 7;
            grpAdd.TabStop = false;
            grpAdd.Text = "할 일 추가";
            grpAdd.Controls.Add(txtNewTask);
            grpAdd.Controls.Add(btnAdd);
            // 
            // grpList
            // 
            grpList.Location = new Point(20, 115);
            grpList.Name = "grpList";
            grpList.Size = new Size(250, 160);
            grpList.TabIndex = 8;
            grpList.TabStop = false;
            grpList.Text = "할 일 목록";
            grpList.Controls.Add(lstTasks);
            grpList.Controls.Add(chkCompleted);
            grpList.Controls.Add(btnRemove);
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(grpList);
            Controls.Add(grpAdd);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNewTask;
        private Button btnAdd;
        private ListBox lstTasks;
        private Button btnRemove;
        private Button btnSave;
        private Button btnLoad;
        private CheckBox chkCompleted;
        private GroupBox grpAdd;
        private GroupBox grpList;
    }
}
