﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rockpapergame
{
    public partial class Form1 : Form
    {

        private int userScore = 0;
        private int computerScore = 0;

        private Random random = new Random();

        private string[] choices = { "가위", "바위", "보" };

        public Form1()
        {
            InitializeComponent();
            UpdateScoreLabel();
        }


        private void CommonButton_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            string userChoice = clickedButton.Text;

            int computerChoiceIndex = random.Next(0, 3);
            string computerChoice = choices[computerChoiceIndex];

            string userImagePath = GetImagePath(userChoice);
            string computerImagePath = GetImagePath(computerChoice);

            if (!File.Exists(userImagePath) || !File.Exists(computerImagePath))
            {
                MessageBox.Show(
                    "이미지 파일을 찾을 수 없습니다.\n" +
                    "실행 파일 폴더의 Images 폴더에 가위.png, 바위.png, 보.png 파일을 넣어 주세요.",
                    "이미지 파일 오류",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            picUser.Image = Image.FromFile(userImagePath);
            picComputer.Image = Image.FromFile(computerImagePath);

            string result = DetermineWinner(userChoice, computerChoice);
            lblResult.Text = result;

            UpdateScore(result);
        }

        private string GetImagePath(string choice)
        {
            return Path.Combine(Application.StartupPath, "Images", $"{choice}.png");
        }

        private string DetermineWinner(string user, string computer)
        {
            if (user == computer)
            {
                return "비겼습니다!";
            }
            else if ((user == "가위" && computer == "보") ||
                     (user == "바위" && computer == "가위") ||
                     (user == "보" && computer == "바위"))
            {
                return "당신이 이겼습니다!";
            }
            else
            {
                return "컴퓨터가 이겼습니다.";
            }
        }

        private void UpdateScore(string result)
        {
            if (result == "당신이 이겼습니다!")
            {
                userScore++;
            }
            else if (result == "컴퓨터가 이겼습니다.")
            {
                computerScore++;
            }
            UpdateScoreLabel();
        }

        private void UpdateScoreLabel()
        {
            lblScore.Text = $"나: {userScore}승, 컴퓨터: {computerScore}승";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void picUser_Click(object sender, EventArgs e)
        {

        }
    }
}
