using System;
using System.Windows.Forms;
namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 폼이 로드될 때 초기화가 필요하면 여기에 추가하세요.
        }

        private int AddNumbers(int a, int b)
        {
            return a + b;
        }
        private int SubtractNumbers(int a, int b)
        {
            return a - b;
        }
        private int MultiplyNumbers(int a, int b)
        {
            return a * b;
        }
        private double DivideNumbers(double a, double b)
        {
            if (b == 0)
            {
                MessageBox.Show("0으로 나눌 수 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
            return a / b;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 입력값을 안전하게 파싱하여 잘못된 입력에 대해 사용자에게 알립니다.
            if (!int.TryParse(txtNum1.Text, out int num1))
            {
                MessageBox.Show("첫 번째 숫자를 올바르게 입력하세요.", "입력 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNum1.Focus();
                return;
            }

            if (!int.TryParse(txtNum2.Text, out int num2))
            {
                MessageBox.Show("두 번째 숫자를 올바르게 입력하세요.", "입력 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNum2.Focus();
                return;
            }

            // 메서드를 호출하여 결과 얻기
            int result = AddNumbers(num1, num2);

            // 결과를 문자열로 변환하여 Label에 표시
            lblResult.Text = result.ToString();
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtNum1.Text, out int num1) ||
                !int.TryParse(txtNum2.Text, out int num2))
            {
                MessageBox.Show("숫자를 올바르게 입력하세요.", "입력 오류", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int result = SubtractNumbers(num1, num2);
            lblResult.Text = result.ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            int result = MultiplyNumbers(num1, num2);
            lblResult.Text = result.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            double result = DivideNumbers(num1, num2);
            lblResult.Text = result.ToString();
        }
    }
}

