﻿namespace todolist
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTodoItem = new TextBox();
            btnAdd = new Button();
            lstTodoList = new ListBox();
            btnRemove = new Button();
            btnSave = new Button();
            btnLoad = new Button();
            SuspendLayout();
            // 
            // txtTodoItem
            // 
            txtTodoItem.Location = new Point(29, 44);
            txtTodoItem.Name = "txtTodoItem";
            txtTodoItem.Size = new Size(132, 23);
            txtTodoItem.TabIndex = 0;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(184, 44);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(75, 23);
            btnAdd.TabIndex = 1;
            btnAdd.Text = "추가";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // lstTodoList
            // 
            lstTodoList.FormattingEnabled = true;
            lstTodoList.Location = new Point(29, 116);
            lstTodoList.Name = "lstTodoList";
            lstTodoList.Size = new Size(120, 94);
            lstTodoList.TabIndex = 2;
            // 
            // btnRemove
            // 
            btnRemove.Location = new Point(174, 142);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(95, 44);
            btnRemove.TabIndex = 3;
            btnRemove.Text = "삭제";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(74, 267);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 4;
            btnSave.Text = "저장";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnLoad
            // 
            btnLoad.Location = new Point(194, 267);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(75, 23);
            btnLoad.TabIndex = 5;
            btnLoad.Text = "불러오기";
            btnLoad.UseVisualStyleBackColor = true;
            btnLoad.Click += btnLoad_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnLoad);
            Controls.Add(btnSave);
            Controls.Add(btnRemove);
            Controls.Add(lstTodoList);
            Controls.Add(btnAdd);
            Controls.Add(txtTodoItem);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtTodoItem;
        private Button btnAdd;
        private ListBox lstTodoList;
        private Button btnRemove;
        private Button btnSave;
        private Button btnLoad;
    }
}
