namespace todolist
{
    public partial class Form1 : Form
    {
        private List<string> todoItems = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 텍스트 박스에 내용이 있는지 확인
            if (!string.IsNullOrWhiteSpace(txtTodoItem.Text))
            {
                // 1. 리스트에 할 일 추가
                todoItems.Add(txtTodoItem.Text);

                // 2. ListBox의 내용을 갱신
                RefreshListBox();

                // 3. 텍스트 박스 초기화 및 포커스 이동
                txtTodoItem.Clear();
                txtTodoItem.Focus();
            }
        }
        private void btnRemove_Click(object sender, EventArgs e)
        {
            // ListBox에서 선택된 항목이 있는지 확인
            if (lstTodoList.SelectedIndex != -1)
            {
                // 1. 리스트에서 해당 항목 제거
                int selectedIndex = lstTodoList.SelectedIndex;
                todoItems.RemoveAt(selectedIndex);

                // 2. ListBox의 내용 갱신
                RefreshListBox();
            }
        }

        // 리스트 내용을 ListBox에 다시 채워주는 메서드
        private void RefreshListBox()
        {
            lstTodoList.Items.Clear(); // ListBox의 모든 항목 제거
            foreach (string item in todoItems)
            {
                lstTodoList.Items.Add(item); // 리스트의 항목들을 ListBox에 추가
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // 파일 저장 경로 설정
            string filePath = "todolist.txt";

            try
            {
                // using 문을 사용하면 StreamWriter 객체가 자동으로 해제됩니다.
                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    foreach (string item in todoItems)
                    {
                        // 리스트의 각 항목을 한 줄씩 파일에 씁니다.
                        writer.WriteLine(item);
                    }
                }
                MessageBox.Show("할 일 목록이 성공적으로 저장되었습니다.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"파일 저장 중 오류가 발생했습니다: {ex.Message}");
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            // 파일 불러오기 경로 설정
            string filePath = "todolist.txt";

            if (File.Exists(filePath)) // 파일이 존재하는지 확인
            {
                try
                {
                    // 기존 리스트와 ListBox 항목을 모두 비웁니다.
                    todoItems.Clear();
                    lstTodoList.Items.Clear();

                    // using 문을 사용하면 StreamReader 객체가 자동으로 해제됩니다.
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string? line;
                        // 파일의 끝까지 한 줄씩 읽습니다.
                        while ((line = reader.ReadLine()) != null)
                        {
                            // 읽어온 데이터는 내부 리스트에만 추가합니다.
                            todoItems.Add(line);
                        }
                    }

                    // ListBox 갱신은 한 번만 수행합니다.
                    RefreshListBox();

                    MessageBox.Show("할 일 목록을 성공적으로 불러왔습니다.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"파일 불러오기 중 오류가 발생했습니다: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("저장된 파일이 존재하지 않습니다.");
            }
        }
    }
    }
