﻿namespace WindowsFormsApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_on = new Button();
            button_off = new Button();
            SuspendLayout();
            // 
            // button_on
            // 
            button_on.Location = new Point(92, 115);
            button_on.Name = "button_on";
            button_on.Size = new Size(159, 73);
            button_on.TabIndex = 0;
            button_on.Text = "LED ON";
            button_on.UseVisualStyleBackColor = true;
            // 
            // button_off
            // 
            button_off.Location = new Point(302, 115);
            button_off.Name = "button_off";
            button_off.Size = new Size(152, 73);
            button_off.TabIndex = 1;
            button_off.Text = "LED OFF";
            button_off.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button_off);
            Controls.Add(button_on);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button button_on;
        private Button button_off;
    }
}
