namespace test4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            // 1. 선택된 계절 찾기 (RadioButton은 하나만 선택 가능)
            string selectedSeason = "선택된 계절 없음";
            foreach (Control ctrl in groupBox1.Controls)
            {
                if (ctrl is RadioButton)
                {
                    RadioButton rb = (RadioButton)ctrl;
                    if (rb.Checked)
                    {
                        selectedSeason = rb.Text;
                        break; // 하나만 찾으면 반복문 탈출
                    }
                }
            }

            // 2. 선택된 음료 찾기 (CheckBox는 여러 개 선택 가능)
            string selectedBeverages = "선택된 음료 없음";
            foreach (Control ctrl in groupBox2.Controls)
            {
                if (ctrl is CheckBox)
                {
                    CheckBox cb = (CheckBox)ctrl;
                    if (cb.Checked)
                    {
                        if (selectedBeverages == "선택된 음료 없음")
                        {
                            selectedBeverages = cb.Text;
                        }
                        else
                        {
                            selectedBeverages += ", " + cb.Text;
                        }
                    }
                }
            }

            // 3. 결과를 메시지 상자에 표시
            MessageBox.Show($"선택된 계절: {selectedSeason}\n선택된 음료: {selectedBeverages}", "투표 결과");
        }
    }
}
