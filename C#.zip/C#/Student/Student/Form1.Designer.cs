﻿namespace Student
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtStudentId = new TextBox();
            btnAdd = new Button();
            lstStudents = new ListBox();
            lblDetails = new Label();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Location = new Point(15, 18);
            txtName.Name = "txtName";
            txtName.Size = new Size(100, 23);
            txtName.TabIndex = 0;
            // 
            // txtStudentId
            // 
            txtStudentId.Location = new Point(15, 47);
            txtStudentId.Name = "txtStudentId";
            txtStudentId.Size = new Size(100, 23);
            txtStudentId.TabIndex = 1;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(133, 34);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(100, 36);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "추가";
            btnAdd.UseVisualStyleBackColor = true;
            // 
            // lstStudents
            // 
            lstStudents.FormattingEnabled = true;
            lstStudents.Location = new Point(15, 112);
            lstStudents.Name = "lstStudents";
            lstStudents.Size = new Size(209, 184);
            lstStudents.TabIndex = 3;
            // 
            // lblDetails
            // 
            lblDetails.AutoSize = true;
            lblDetails.Location = new Point(15, 329);
            lblDetails.Name = "lblDetails";
            lblDetails.Size = new Size(39, 15);
            lblDetails.TabIndex = 4;
            lblDetails.Text = "label1";
            lblDetails.Click += lblDetails_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblDetails);
            Controls.Add(lstStudents);
            Controls.Add(btnAdd);
            Controls.Add(txtStudentId);
            Controls.Add(txtName);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtName;
        private TextBox txtStudentId;
        private Button btnAdd;
        private ListBox lstStudents;
        private Label lblDetails;
    }
}
